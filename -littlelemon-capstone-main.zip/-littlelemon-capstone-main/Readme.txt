API paths for peer review testing:

/api/bookings/
/api/registration/